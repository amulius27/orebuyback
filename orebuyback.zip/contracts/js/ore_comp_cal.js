$(document).ready(function() {
    calcNow();
});
$('#calc-input-Veldspar_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Veldspar_units-value').on('focusout', function(){
    calcInputGetValue('Veldspar_units');
});
$('#calc-input-Veldspar_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Veldspar_units_5-value').on('focusout', function(){
    calcInputGetValue('Veldspar_units_5');
});
$('#calc-input-Veldspar_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Veldspar_units_10-value').on('focusout', function(){
    calcInputGetValue('Veldspar_units_10');
});
$('#calc-input-Scordite_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Scordite_units-value').on('focusout', function(){
    calcInputGetValue('Scordite_units');
});
$('#calc-input-Scordite_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Scordite_units_5-value').on('focusout', function(){
    calcInputGetValue('Scordite_units_5');
});
$('#calc-input-Scordite_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Scordite_units_10-value').on('focusout', function(){
    calcInputGetValue('Scordite_units_10');
});
$('#calc-input-Pyroxeres_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Pyroxeres_units-value').on('focusout', function(){
    calcInputGetValue('Pyroxeres_units');
});
$('#calc-input-Pyroxeres_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Pyroxeres_units_5-value').on('focusout', function(){
    calcInputGetValue('Pyroxeres_units_5');
});
$('#calc-input-Pyroxeres_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Pyroxeres_units_10-value').on('focusout', function(){
    calcInputGetValue('Pyroxeres_units_10');
});
$('#calc-input-Plagioclase_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Plagioclase_units-value').on('focusout', function(){
    calcInputGetValue('Plagioclase_units');
});
$('#calc-input-Plagioclase_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Plagioclase_units_5-value').on('focusout', function(){
    calcInputGetValue('Plagioclase_units_5');
});
$('#calc-input-Plagioclase_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Plagioclase_units_10-value').on('focusout', function(){
    calcInputGetValue('Plagioclase_units_10');
});
$('#calc-input-Omber_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Omber_units-value').on('focusout', function(){
    calcInputGetValue('Omber_units');
});
$('#calc-input-Omber_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-POmber_units_5-value').on('focusout', function(){
    calcInputGetValue('Omber_units_5');
});
$('#calc-input-Omber_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Omber_units_10-value').on('focusout', function(){
    calcInputGetValue('Omber_units_10');
});
$('#calc-input-Kernite_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Kernite_units-value').on('focusout', function(){
    calcInputGetValue('Kernite_units');
});
$('#calc-input-Kernite_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Kernite_units_5-value').on('focusout', function(){
    calcInputGetValue('Kernite_units_5');
});
$('#calc-input-Kernite_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Kernite_units_10-value').on('focusout', function(){
    calcInputGetValue('Kernite_units_10');
});
$('#calc-input-Jaspet_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Jaspet_units-value').on('focusout', function(){
    calcInputGetValue('Jaspet_units');
});
$('#calc-input-Jaspet_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Jaspet_units_5-value').on('focusout', function(){
    calcInputGetValue('Jaspet_units_5');
});
$('#calc-input-Jaspet_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Jaspet_units_10-value').on('focusout', function(){
    calcInputGetValue('Jaspet_units_10');
});
$('#calc-input-Hemorphite_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Hemorphite_units-value').on('focusout', function(){
    calcInputGetValue('Hemorphite_units');
});
$('#calc-input-Hemorphite_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Hemorphite_units_5-value').on('focusout', function(){
    calcInputGetValue('Hemorphite_units_5');
});
$('#calc-input-Hemorphite_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Hemorphite_units_10-value').on('focusout', function(){
    calcInputGetValue('Hemorphite_units_10');
});
$('#calc-input-Hedbergite_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Hedbergite_units-value').on('focusout', function(){
    calcInputGetValue('Hedbergite_units');
});
$('#calc-input-Hedbergite_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Hedbergite_units_5-value').on('focusout', function(){
    calcInputGetValue('Hedbergite_units_5');
});
$('#calc-input-Hedbergite_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Hedbergite_units_10-value').on('focusout', function(){
    calcInputGetValue('Hedbergite_units_10');
});
$('#calc-input-Gneiss_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Gneiss_units-value').on('focusout', function(){
    calcInputGetValue('Gneiss_units');
});
$('#calc-input-Gneiss_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Gneiss_units_5-value').on('focusout', function(){
    calcInputGetValue('Gneiss_units_5');
});
$('#calc-input-Gneiss_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Gneiss_units_10-value').on('focusout', function(){
    calcInputGetValue('Gneiss_units_10');
});
$('#calc-input-Dark_Ochre_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Dark_Ochre_units-value').on('focusout', function(){
    calcInputGetValue('Dark_Ochre_units');
});
$('#calc-input-Dark_Ochre_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Dark_Ochre_units_5-value').on('focusout', function(){
    calcInputGetValue('Dark_Ochre_units_5');
});
$('#calc-input-Dark_Ochre_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Dark_Ochre_units_10-value').on('focusout', function(){
    calcInputGetValue('Dark_Ochre_units_10');
});
$('#calc-input-Spodumain_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Spodumain_units-value').on('focusout', function(){
    calcInputGetValue('Spodumain_units');
});
$('#calc-input-Spodumain_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Spodumain_units_5-value').on('focusout', function(){
    calcInputGetValue('Spodumain_units_5');
});
$('#calc-input-Spodumain_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Spodumain_units_10-value').on('focusout', function(){
    calcInputGetValue('Spodumain_units_10');
});
$('#calc-input-Crokite_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Crokite_units-value').on('focusout', function(){
    calcInputGetValue('Crokite_units');
});
$('#calc-input-Crokite_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Crokite_units_5-value').on('focusout', function(){
    calcInputGetValue('Crokite_units_5');
});
$('#calc-input-Crokite_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Crokite_units_10-value').on('focusout', function(){
    calcInputGetValue('Crokite_units_10');
});
$('#calc-input-Bistot_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Bistot_units-value').on('focusout', function(){
    calcInputGetValue('Bistot_units');
});
$('#calc-input-Bistot_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Bistot_units_5-value').on('focusout', function(){
    calcInputGetValue('Bistot_units_5');
});
$('#calc-input-Bistot_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Bistot_units_10-value').on('focusout', function(){
    calcInputGetValue('Bistot_units_10');
});
$('#calc-input-Arkonor_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Arkonor_units-value').on('focusout', function(){
    calcInputGetValue('Arkonor_units');
});
$('#calc-input-Arkonor_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Arkonor_units_5-value').on('focusout', function(){
    calcInputGetValue('Arkonor_units_5');
});
$('#calc-input-Arkonor_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Arkonor_units_10-value').on('focusout', function(){
    calcInputGetValue('Arkonor_units_10');
});
$('#calc-input-Mercoxit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Mercoxit_units-value').on('focusout', function(){
    calcInputGetValue('Mercoxit_units');
});
$('#calc-input-Mercoxit_units_5-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Mercoxit_units_5-value').on('focusout', function(){
    calcInputGetValue('Mercoxit_units_5');
});
$('#calc-input-Mercoxit_units_10-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Mercoxit_units_10-value').on('focusout', function(){
    calcInputGetValue('Mercoxit_units_10');
});

function calcInputClear(objname) {
    $('#calc-input-' + objname + '-form').removeClass('has-error');
    $('#calc-input-' + objname + '-error').html('');
    $('#calc-input-' + objname + '-incursion').addClass('hidden');
}

function calcInputError(objname, text) {
    $('#calc-input-' + objname + '-form').addClass('has-error');
    $('#calc-input-' + objname + '-error').html(text);
}

function calcInputGetValue(name) {

    calcInputClear(name);

    var value = $('#calc-input-' + name + '-value').val();

    return value;
}

function calcNow() {
    var veldsparUnits = calcInputGetValue('Veldspar_units'), veldspar_5Units = calcInputGetValue('Veldspar_units_5'), veldspar_10Units = calcInputGetValue('Veldspar_units_10');
    var scroditeUnits = calcInputGetValue('Scordite_units'), scordite_5Units = calcInputGetValue('Scordite_units_5'), scordite_10Units = calcInputGetValue('Scordite_units_10');
    var pyroxeresUnits = calcInputGetValue('Pyroxeres_units'), pyroxeres_5Units = calcInputGetValue('Pyroxeres_units_5'), pyroxeres_10Units = calcInputGetValue('Pyroxeres_units_10');
    var plagioclaseUnits = calcInputGetValue('Plagioclase_units'), plagioclase_5Units = calcInputGetValue('Plagioclase_units_5'), plagioclase_10Units = calcInputGetValue('Plagioclase_units_10');
    var omberUnits = calcInputGetValue('Omber_units'), omber_5Units = calcInputGetValue('Omber_units_5'), omber_10Units = calcInputGetValue('Omber_units_10');
    var kerniteUnits = calcInputGetValue('Kernite_units'), kernite_5Units = calcInputGetValue('Kernite_units_5'), kernite_10Units = calcInputGetValue('Kernite_units_10');
    var jaspetUnits = calcInputGetValue('Jaspet_units'), jaspet_5Units = calcInputGetValue('Jaspet_units_5'), jaspet_10Units = calcInputGetValue('Jaspet_units_10');
    var hemorphiteUnits = calcInputGetValue('Hemorphite_units'), hemorphite_5Units = calcInputGetValue('Hemorphite_units_5'), hemorphite_10Units = calcInputGetValue('Hemorphite_units_10');
    var hedbergiteUnits = calcInputGetValue('Hedbergite_units'), hedbergite_5Units = calcInputGetValue('Hedbergite_units_5'), hedbergite_10Units = calcInputGetValue('Hedbergite_units_10');
    var gneissUnits = calcInputGetValue('Gneiss_units'), gneiss_5Units = calcInputGetValue('Gneiss_units_5'), gneiss_10Units = calcInputGetValue('Gneiss_units_10');
    var darkOchreUnits = calcInputGetValue('Dark_Ochre_units'), darkOchre_5Units = calcInputGetValue('Dark_Ochre_units_5'), darkOchre_10Units = calcInputGetValue('Dark_Ochre_units_10');
    var spodumainUnits = calcInputGetValue('Spodumain_units'), spodumain_5Units = calcInputGetValue('Spodumain_units_5'), spodumain_10Units = calcInputGetValue('Spodumain_units_10');
    var crokiteUnits = calcInputGetValue('Crokite_units'), crokite_5Units = calcInputGetValue('Crokite_units_5'), crokite_10Units = calcInputGetValue('Crokite_units_10');
    var bistotUnits = calcInputGetValue('Bistot_units'), bistot_5Units = calcInputGetValue('Bistot_units_5'), bistot_10Units = calcInputGetValue('Bistot_units_10');
    var arkonorUnits = calcInputGetValue('Arkonor_units'), arkonor_5Units = calcInputGetValue('Arkonor_units_5'), arkonor_10Units = calcInputGetValue('Arkonor_units_10');
    var mercoxitUnits = calcInputGetValue('Mercoxit_units'), mercoxit_5Units = calcInputGetValue('Mercoxit_units_5'), mercoxit_10Units = calcInputGetValue('Mercoxit_units_10');

    var veldsparReward = (veldsparUnits*veldspar_comp)+(veldspar_5Units*(veldspar_comp*1.05))+(veldspar_10Units*(veldspar_comp*1.1));
    var scorditeReward = (scroditeUnits*scordite_comp)+(scordite_5Units*(scordite_comp*1.05))+(scordite_10Units*(scordite_comp*1.1));
    var pyroxeresReward = (pyroxeresUnits*pyroxeres_comp)+(pyroxeres_5Units*(pyroxeres_comp*1.05))+(pyroxeres_10Units*(pyroxeres_comp*1.1));
    var plagioclaseReward = (plagioclaseUnits*plagioclase_comp)+(plagioclase_5Units*(plagioclase_comp*1.05))+(plagioclase_10Units*(plagioclase_comp*1.1));
    var omberReward = (omberUnits*omber_comp)+(omber_5Units*(omber_comp*1.05))+(omber_10Units*(omber_comp*1.1));
    var kerniteReward = (kerniteUnits*kernite_comp)+(kernite_5Units*(kernite_comp*1.05))+(kernite_10Units*(kernite_comp*1.1));
    var jaspetReward = (jaspetUnits*jaspet_comp)+(jaspet_5Units*(jaspet_comp*1.05))+(jaspet_10Units*(jaspet_comp*1.1));
    var hemorphiteReward = (hemorphiteUnits*hemorphite_comp)+(hemorphite_5Units*(hemorphite_comp*1.05))+(hemorphite_10Units*(hemorphite_comp*1.1));
    var hedbergiteReward = (hedbergiteUnits*hedbergite_comp)+(hedbergite_5Units*(hedbergite_comp*1.05))+(hedbergite_10Units*(hedbergite_comp*1.1));
    var gneissReward = (gneissUnits*gneiss_comp)+(gneiss_5Units*(gneiss_comp*1.05))+(gneiss_10Units*(gneiss_comp*1.1));
    var darkOchreReward = (darkOchreUnits*dark_ochre_comp)+(darkOchre_5Units*(dark_ochre_comp*1.05))+(darkOchre_10Units*(dark_ochre_comp*1.1));
    var spodumainReward = (spodumainUnits*spodumain_comp)+(spodumain_5Units*(spodumain_comp*1.05))+(spodumain_10Units*(spodumain_comp*1.1));
    var crokiteReward = (crokiteUnits*crokite_comp)+(crokite_5Units*(crokite_comp*1.05))+(crokite_10Units*(crokite_comp*1.1));
    var bistotReward = (bistotUnits*bistot_comp)+(bistot_5Units*(bistot_comp*1.05))+(bistot_10Units*(bistot_comp*1.1));
    var arkonorReward = (arkonorUnits*arkonor_comp)+(arkonor_5Units*(arkonor_comp*1.05))+(arkonor_10Units*(arkonor_comp*1.1));
    var mercoxitReward = (mercoxitUnits*mercoxit_comp)+(mercoxit_5Units*(mercoxit_comp*1.05))+(mercoxit_10Units*(mercoxit_comp*1.1));

    var totalReward = (veldsparReward+scorditeReward+pyroxeresReward+plagioclaseReward+omberReward+kerniteReward+jaspetReward+
        hemorphiteReward+hedbergiteReward+gneissReward+darkOchreReward+spodumainReward+crokiteReward+bistotReward+arkonorReward+mercoxitReward) * value;

    var reward = totalReward.toFixed(2);

    $('#calc-output-veldspar-value').html(number_format(veldsparReward) + ' ISK');
    $('#calc-output-scordite-value').html(number_format(scorditeReward) + ' ISK');
    $('#calc-output-pyroxeres-value').html(number_format(pyroxeresReward) + ' ISK');
    $('#calc-output-plagioclase-value').html(number_format(plagioclaseReward) + ' ISK');
    $('#calc-output-omber-value').html(number_format(omberReward) + ' ISK');
    $('#calc-output-kernite-value').html(number_format(kerniteReward) + ' ISK');
    $('#calc-output-jaspet-value').html(number_format(jaspetReward) + ' ISK');
    $('#calc-output-hemorphite-value').html(number_format(hemorphiteReward) + ' ISK');
    $('#calc-output-hedbergite-value').html(number_format(hedbergiteReward) + ' ISK');
    $('#calc-output-gneiss-value').html(number_format(gneissReward) + ' ISK');
    $('#calc-output-dark_ochre-value').html(number_format(darkOchreReward) + ' ISK');
    $('#calc-output-spodumain-value').html(number_format(spodumainReward) + ' ISK');
    $('#calc-output-crokite-value').html(number_format(crokiteReward) + ' ISK');
    $('#calc-output-bistot-value').html(number_format(bistotReward) + ' ISK');
    $('#calc-output-arkonor-value').html(number_format(arkonorReward) + ' ISK');
    $('#calc-output-mercoxit-value').html(number_format(mercoxitReward) + ' ISK');

    $('#calc-output-reward-value').html(number_format(totalReward) + ' ISK');

    return reward;
}

function number_format (number, decimals, dec_point, thousands_sep)
{
    number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 2 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
            var k = Math.pow(10, prec);
            return '' + Math.round(n * k) / k;
        };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}