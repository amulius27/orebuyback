$(document).ready(function() {
    calcNow();
});

$('#calc-input-Alloyed_Tritanium_Bar_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Alloyed_Tritanium_Bar_units-value').on('focusout', function(){
    calcInputGetValue('Alloyed_Tritanium_Bar_units');
});
$('#calc-input-Armor_Plates_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Armor_Plates_units-value').on('focusout', function(){
    calcInputGetValue('Armor_Plates_units');
});
$('#calc-input-Artificial_Neural_Network_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Artificial_Neural_Network_units-value').on('focusout', function(){
    calcInputGetValue('Artificial_Neural_Network_units');
});
$('#calc-input-Broken_Drone_Transceiver_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Broken_Drone_Transceiver_units-value').on('focusout', function(){
    calcInputGetValue('Broken_Drone_Transceiver_units');
});
$('#calc-input-Burned_Logic_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Burned_Logic_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Burned_Logic_Circuit_units');
});
$('#calc-input-Capacitor_Console_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Capacitor_Console_units-value').on('focusout', function(){
    calcInputGetValue('Capacitor_Console_units');
});
$('#calc-input-Charred_Micro_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Charred_Micro_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Charred_Micro_Circuit_units');
});
$('#calc-input-Conductive_Polymer_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Conductive_Polymer_units-value').on('focusout', function(){
    calcInputGetValue('Conductive_Polymer_units');
});
$('#calc-input-Conductive_Thermoplastic_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Conductive_Thermoplastic_units-value').on('focusout', function(){
    calcInputGetValue('Conductive_Thermoplastic_units');
});
$('#calc-input-Contaminated_Lorentz_Fluid_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Contaminated_Lorentz_Fluid_units-value').on('focusout', function(){
    calcInputGetValue('Contaminated_Lorentz_Fluid_units');
});
$('#calc-input-Contaminated_Nanite_Compound_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Contaminated_Nanite_Compound_units-value').on('focusout', function(){
    calcInputGetValue('Contaminated_Nanite_Compound_units');
});
$('#calc-input-Current_Pump_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Current_Pump_units-value').on('focusout', function(){
    calcInputGetValue('Current_Pump_units');
});
$('#calc-input-Damaged_Artificial_Neural_Network_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Damaged_Artificial_Neural_Network_units-value').on('focusout', function(){
    calcInputGetValue('Damaged_Artificial_Neural_Network_units');
});
$('#calc-input-Defective_Current_Pump_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Defective_Current_Pump_units-value').on('focusout', function(){
    calcInputGetValue('Defective_Current_Pump_units');
});
$('#calc-input-Drone_Transceiver_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Drone_Transceiver_units-value').on('focusout', function(){
    calcInputGetValue('Drone_Transceiver_units');
});

$('#calc-input-Enhanced_Ward_Console_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Enhanced_Ward_Console_units-value').on('focusout', function(){
    calcInputGetValue('Enhanced_Ward_Console_units');
});
$('#calc-input-Fried_Interface_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Fried_Interface_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Fried_Interface_Circuit_units');
});
$('#calc-input-Impetus_Console_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Impetus_Console_units-value').on('focusout', function(){
    calcInputGetValue('Impetus_Console_units');
});
$('#calc-input-Intact_Armor_Plates_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Intact_Armor_Plates_units-value').on('focusout', function(){
    calcInputGetValue('Intact_Armor_Plates_units');
});
$('#calc-input-Intact_Shield_Emitter_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Intact_Shield_Emitter_units-value').on('focusout', function(){
    calcInputGetValue('Intact_Shield_Emitter_units');
});
$('#calc-input-Interface_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Interface_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Interface_Circuit_units');
});
$('#calc-input-Logic_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Logic_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Logic_Circuit_units');
});
$('#calc-input-Lorentz_Fluid_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Lorentz_Fluid_units-value').on('focusout', function(){
    calcInputGetValue('Lorentz_Fluid_units');
});
$('#calc-input-Malfunctioning_Shield_Emitter_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Malfunctioning_Shield_Emitter_units-value').on('focusout', function(){
    calcInputGetValue('Malfunctioning_Shield_Emitter_units');
});
$('#calc-input-Melted_Capacitor_Console_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Melted_Capacitor_Console_units-value').on('focusout', function(){
    calcInputGetValue('Melted_Capacitor_Console_units');
});
$('#calc-input-Micro_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Micro_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Micro_Circuit_units');
});
$('#calc-input-Nanite_Compound_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Nanite_Compound_units-value').on('focusout', function(){
    calcInputGetValue('Nanite_Compound_units');
});
$('#calc-input-Power_Circuit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Power_Circuit_units-value').on('focusout', function(){
    calcInputGetValue('Power_Circuit_units');
});
$('#calc-input-Power_Conduit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Power_Conduit_units-value').on('focusout', function(){
    calcInputGetValue('Power_Conduit_units');
});
$('#calc-input-Scorched_Telemetry_Processor_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Scorched_Telemetry_Processor_units-value').on('focusout', function(){
    calcInputGetValue('Scorched_Telemetry_Processor_units');
});
$('#calc-input-Single_crystal_Superalloy_I_beam_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Single_crystal_Superalloy_I_beam_units-value').on('focusout', function(){
    calcInputGetValue('Single_crystal_Superalloy_I_beam_units');
});
$('#calc-input-Smashed_Trigger_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Smashed_Trigger_units-value').on('focusout', function(){
    calcInputGetValue('Smashed_Trigger_units');
});
$('#calc-input-Tangled_Power_Conduit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Tangled_Power_Conduit_units-value').on('focusout', function(){
    calcInputGetValue('Tangled_Power_Conduit_units');
});
$('#calc-input-Telemetry_Processor_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Telemetry_Processor_units-value').on('focusout', function(){
    calcInputGetValue('Telemetry_Processor_units');
});
$('#calc-input-Thruster_Console_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Thruster_Console_units-value').on('focusout', function(){
    calcInputGetValue('Thruster_Console_units');
});
$('#calc-input-Trigger_Unit_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Trigger_Unit_units-value').on('focusout', function(){
    calcInputGetValue('Trigger_Unit_units');
});
$('#calc-input-Tripped_Power_Circuit-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Tripped_Power_Circuit-value').on('focusout', function(){
    calcInputGetValue('Tripped_Power_Circuit');
});
$('#calc-input-Ward_Console_units-value').on('propertychange change keyup paste input', function() {
    calcNow();
});
$('#calc-input-Ward_Console_units-value').on('focusout', function(){
    calcInputGetValue('Ward_Console_units');
});

function calcInputClear(objname) {
    $('#calc-input-' + objname + '-form').removeClass('has-error');
    $('#calc-input-' + objname + '-error').html('');
    $('#calc-input-' + objname + '-incursion').addClass('hidden');
}

function calcInputError(objname, text) {
    $('#calc-input-' + objname + '-form').addClass('has-error');
    $('#calc-input-' + objname + '-error').html(text);
}

function calcInputGetValue(name) {

    calcInputClear(name);

    var value = $('#calc-input-' + name + '-value').val();

    return value;
}

function calcNow() {

    var alloyedTritaniumBarUnits = calcInputGetValue('Alloyed_Tritanium_Bar_units');
    var armorPlatesUnits = calcInputGetValue('Armor_Plates_units');
    var artificialNeuralNetworkUnits = calcInputGetValue('Artificial_Neural_Network_units');
    var brokenDroneTransceiverUnits = calcInputGetValue('Broken_Drone_Transceiver_units');
    var burnedLogicCircuitUnits = calcInputGetValue('Burned_Logic_Circuit_units');
    var capacitorConsoleUnits = calcInputGetValue('Capacitor_Console_units');
    var charredMicroCircuitUnits = calcInputGetValue('Charred_Micro_Circuit_units');
    var conductivePolymerUnits = calcInputGetValue('Conductive_Polymer_units');
    var conductiveThermoplasticUnits = calcInputGetValue('Conductive_Thermoplastic_units');
    var contaminatedLorentzFluidUnits = calcInputGetValue('Contaminated_Lorentz_Fluid_units');
    var contaminatedNaniteCompoundUnits = calcInputGetValue('Contaminated_Nanite_Compound_units');
    var currentPumpUnits = calcInputGetValue('Current_Pump_units');
    var damagedArtificialNeuralNetworkUnits = calcInputGetValue('Damaged_Artificial_Neural_Network_units');
    var defectiveCurrentPumpUnits = calcInputGetValue('Defective_Current_Pump_units');
    var droneTransceiverUnits = calcInputGetValue('Drone_Transceiver_units');
    var enhancedWardConsoleUnits = calcInputGetValue('Enhanced_Ward_Console_units');
    var friedInterfaceCircuitUnits = calcInputGetValue('Fried_Interface_Circuit_units');
    var impetusConsoleUnits = calcInputGetValue('Impetus_Console_units');
    var intactArmorPlatesUnits = calcInputGetValue('Intact_Armor_Plates_units');
    var intactShieldEmitterUnits = calcInputGetValue('Intact_Shield_Emitter_units');
    var interfaceCircuitUnits = calcInputGetValue('Interface_Circuit_units');
    var logicCircuitUnits = calcInputGetValue('Logic_Circuit_units');
    var lorentzFluidUnits = calcInputGetValue('Lorentz_Fluid_units');
    var malfunctioningShieldEmitterUnits = calcInputGetValue('Malfunctioning_Shield_Emitter_units');
    var meltedCapacitorConsoleUnits = calcInputGetValue('Melted_Capacitor_Console_units');
    var microCircuitUnits = calcInputGetValue('Micro_Circuit_units');
    var naniteCompoundUnits = calcInputGetValue('Nanite_Compound_units');
    var powerCircuitUnits = calcInputGetValue('Power_Circuit_units');
    var powerConduitUnits = calcInputGetValue('Power_Conduit_units');
    var scorchedTelemetryProcessorUnits = calcInputGetValue('Scorched_Telemetry_Processor_units');
    var singleCrystalSuperalloyIBeamUnits = calcInputGetValue('Single_crystal_Superalloy_I_beam_units');
    var smashedTriggerUnitUnits = calcInputGetValue('Smashed_Trigger_units');
    var tangledPowerConduitUnits = calcInputGetValue('Tangled_Power_Conduit_units');
    var telemetryProcessorUnits = calcInputGetValue('Telemetry_Processor_units');
    var thrusterConsoleUnits = calcInputGetValue('Thruster_Console_units');
    var triggerUnitUnits = calcInputGetValue('Trigger_Unit_units');
    var trippedPowerCircuitUnits = calcInputGetValue('Tripped_Power_Circuit');
    var wardConsoleUnits = calcInputGetValue('Ward_Console_units');

    var alloyedTritaniumBarReward = alloyedTritaniumBarUnits * alloyedTritaniumBar;
    var armorPlatesReward = armorPlatesUnits * armorPlates;
    var artificialNeuralNetworkReward = artificialNeuralNetworkUnits * artificialNeuralNetwork;
    var brokenDroneTransceiverReward = brokenDroneTransceiverUnits * brokenDroneTransceiver;
    var burnedLogicCircuitReward = burnedLogicCircuitUnits * burnedLogicCircuit;
    var capacitorConsoleReward = capacitorConsoleUnits * capacitorConsole;
    var charredMicroCircuitReward = charredMicroCircuitUnits * charredMicroCircuit;
    var conductivePolymerReward = conductivePolymerUnits * conductivePolymer;
    var conductiveThermoplasticReward = conductiveThermoplasticUnits * conductiveThermoplastic;
    var contaminatedLorentzFluidReward = contaminatedLorentzFluidUnits * contaminatedLorentzFluid;
    var contaminatedNaniteCompoundReward = contaminatedNaniteCompoundUnits * contaminatedNaniteCompound;
    var currentPumpReward = currentPumpUnits * currentPump;
    var damagedArtificialNeuralNetworkReward = damagedArtificialNeuralNetworkUnits * damagedArtificialNeuralNetwork;
    var defectiveCurrentPumpReward = defectiveCurrentPumpUnits * defectiveCurrentPump;
    var droneTransceiverReward = droneTransceiverUnits * droneTransceiver;
    var enhancedWardConsoleReward = enhancedWardConsoleUnits * enhancedWardConsole;
    var friedInterfaceCircuitReward = friedInterfaceCircuitUnits * friedInterfaceCircuit;
    var impetusConsoleReward = impetusConsoleUnits * impetusConsole;
    var intactArmorPlatesReward = intactArmorPlatesUnits * intactArmorPlates;
    var intactShieldEmitterReward = intactShieldEmitterUnits * intactShieldEmitter;
    var interfaceCircuitReward = interfaceCircuitUnits * interfaceCircuit;
    var logicCircuitReward = logicCircuitUnits * logicCircuit;
    var lorentzFluidReward = lorentzFluidUnits * lorentzFluid;
    var malfunctioningShieldEmitterReward = malfunctioningShieldEmitterUnits * malfunctioningShieldEmitter;
    var meltedCapacitorConsoleReward = meltedCapacitorConsoleUnits * meltedCapacitorConsole;
    var microCircuitReward = microCircuitUnits * microCircuit;
    var naniteCompoundReward = naniteCompoundUnits * naniteCompound;
    var powerCircuitReward = powerCircuitUnits * powerCircuit;
    var powerConduitReward = powerConduitUnits * powerConduit;
    var scorchedTelemetryProcessorReward = scorchedTelemetryProcessorUnits * scorchedTelemetryProcessor;
    var singleCrystalSuperalloyIBeamReward = singleCrystalSuperalloyIBeamUnits * singleCrystalSuperalloyIBeam;
    var smashedTriggerUnitReward = smashedTriggerUnitUnits * smashedTriggerUnit;
    var tangledPowerConduitReward = tangledPowerConduitUnits * tangledPowerConduit;
    var telemetryProcessorReward = telemetryProcessorUnits * telemetryProcessor;
    var thrusterConsoleReward = thrusterConsoleUnits * thrusterConsole;
    var triggerUnitReward = triggerUnitUnits * triggerUnit;
    var trippedPowerCircuitReward = trippedPowerCircuitUnits * trippedPowerCircuit;
    var wardConsoleReward = wardConsoleUnits * wardConsole;

    var totalReward = (alloyedTritaniumBarReward+armorPlatesReward+artificialNeuralNetworkReward+brokenDroneTransceiverReward+burnedLogicCircuitReward+capacitorConsoleReward+charredMicroCircuitReward
        +conductivePolymerReward+conductiveThermoplasticReward+contaminatedLorentzFluidReward+contaminatedNaniteCompoundReward+currentPumpReward+damagedArtificialNeuralNetworkReward+defectiveCurrentPumpReward
        +droneTransceiverReward+enhancedWardConsoleReward+friedInterfaceCircuitReward+impetusConsoleReward+intactArmorPlatesReward+intactShieldEmitterReward+interfaceCircuitReward+logicCircuitReward
        +lorentzFluidReward+malfunctioningShieldEmitterReward+meltedCapacitorConsoleReward+microCircuitReward+naniteCompoundReward+powerCircuitReward+powerConduitReward+scorchedTelemetryProcessorReward
        +singleCrystalSuperalloyIBeamReward+smashedTriggerUnitReward+tangledPowerConduitReward+telemetryProcessorReward+thrusterConsoleReward+triggerUnitReward+trippedPowerCircuitReward+wardConsoleReward) * value;

    var reward = totalReward.toFixed(2);

    $('#calc-output-Alloyed_Tritanium_Bar-value').html(number_format(alloyedTritaniumBarReward ) + ' ISK');
    $('#calc-output-Armor_Plates-value').html(number_format(armorPlatesReward ) + ' ISK');
    $('#calc-output-Artificial_Neural_Network-value').html(number_format(artificialNeuralNetworkReward ) + ' ISK');
    $('#calc-output-Broken_Drone_Transceiver-value').html(number_format(brokenDroneTransceiverReward ) + ' ISK');
    $('#calc-output-Burned_Logic_Circuit-value').html(number_format(burnedLogicCircuitReward ) + ' ISK');
    $('#calc-output-Capacitor_Console-value').html(number_format(capacitorConsoleReward ) + ' ISK');
    $('#calc-output-Charred_Micro_Circuit-value').html(number_format(charredMicroCircuitReward ) + ' ISK');
    $('#calc-output-Conductive_Polymer-value').html(number_format(conductivePolymerReward ) + ' ISK');
    $('#calc-output-Conductive_Thermoplastic-value').html(number_format(conductiveThermoplasticReward ) + ' ISK');
    $('#calc-output-Contaminated_Lorentz_Fluid-value').html(number_format(contaminatedLorentzFluidReward ) + ' ISK');
    $('#calc-output-Contaminated_Nanite_Compound-value').html(number_format(contaminatedNaniteCompoundReward ) + ' ISK');
    $('#calc-output-Current_Pump-value').html(number_format(currentPumpReward ) + ' ISK');
    $('#calc-output-Damaged_Artificial_Neural_Network-value').html(number_format(damagedArtificialNeuralNetworkReward ) + ' ISK');
    $('#calc-output-Defective_Current_Pump-value').html(number_format(defectiveCurrentPumpReward ) + ' ISK');
    $('#calc-output-Drone_Transceiver-value').html(number_format(droneTransceiverReward ) + ' ISK');
    $('#calc-output-Enhanced_Ward_Console-value').html(number_format(enhancedWardConsoleReward ) + ' ISK');
    $('#calc-output-Fried_Interface_Circuit-value').html(number_format(friedInterfaceCircuitReward ) + ' ISK');
    $('#calc-output-Impetus_Console-value').html(number_format(impetusConsoleReward ) + ' ISK');
    $('#calc-output-Intact_Armor_Plates-value').html(number_format(intactArmorPlatesReward ) + ' ISK');
    $('#calc-output-Intact_Shield_Emitter-value').html(number_format(intactShieldEmitterReward ) + ' ISK');
    $('#calc-output-Interface_Circuit-value').html(number_format(interfaceCircuitReward ) + ' ISK');
    $('#calc-output-Logic_Circuit-value').html(number_format(logicCircuitReward ) + ' ISK');
    $('#calc-output-Lorentz_Fluid-value').html(number_format(lorentzFluidReward ) + ' ISK');
    $('#calc-output-Malfunctioning_Shield_Emitter-value').html(number_format(malfunctioningShieldEmitterReward ) + ' ISK');
    $('#calc-output-Melted_Capacitor_Console-value').html(number_format(meltedCapacitorConsoleReward ) + ' ISK');
    $('#calc-output-Micro_Circuit-value').html(number_format(microCircuitReward ) + ' ISK');
    $('#calc-output-Nanite_Compound-value').html(number_format(naniteCompoundReward ) + ' ISK');
    $('#calc-output-Power_Circuit-value').html(number_format(powerCircuitReward ) + ' ISK');
    $('#calc-output-Power_Conduit-value').html(number_format(powerConduitReward ) + ' ISK');
    $('#calc-output-Scorched_Telemetry_Processor-value').html(number_format(scorchedTelemetryProcessorReward ) + ' ISK');
    $('#calc-output-Single_crystal_Superalloy_I_beam-value').html(number_format(singleCrystalSuperalloyIBeamReward ) + ' ISK');
    $('#calc-output-Smashed_Trigger_Unit-value').html(number_format(smashedTriggerUnitReward ) + ' ISK');
    $('#calc-output-Tangled_Power_Conduit-value').html(number_format(tangledPowerConduitReward ) + ' ISK');
    $('#calc-output-Telemetry_Processor-value').html(number_format(telemetryProcessorReward ) + ' ISK');
    $('#calc-output-Thruster_Console-value').html(number_format(thrusterConsoleReward ) + ' ISK');
    $('#calc-output-Trigger_Unit-value').html(number_format(triggerUnitReward ) + ' ISK');
    $('#calc-output-Tripped_Power_Circuit-value').html(number_format(trippedPowerCircuitReward ) + ' ISK');
    $('#calc-output-Ward_Console-value').html(number_format(wardConsoleReward ) + ' ISK');

    $('#calc-output-reward-value').html(number_format(totalReward) + ' ISK');


    return reward;
}

function number_format (number, decimals, dec_point, thousands_sep)
{
    number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 2 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
            var k = Math.pow(10, prec);
            return '' + Math.round(n * k) / k;
        };
    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}