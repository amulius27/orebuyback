<?php

function PrintTitle() {
    printf("<!-- Lead -->
            <div class=\"central-header\">
              <h1>Warped Intentions Buy Back Program</h1>
              <p></p>
              <h4 class=\"text-danger\">This site is still under going massive developments! Report any issues on the Warped Intentions Forums</h4>
            </div>");
}