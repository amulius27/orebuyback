<?php

function PrintCloseIndexPage() {
    printf("<script src=\"js/jquery.cookie.js\"></script> 
            <script src=\"js/eve-link.js\"></script>
            </body>
            </html>");
}
