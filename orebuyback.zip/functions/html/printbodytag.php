<?php

function PrintBodyTag() {
    printf("<body>");
}
