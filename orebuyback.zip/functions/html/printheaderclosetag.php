<?php

function PrintHeaderCloseTag() {
    printf("</head>");
}